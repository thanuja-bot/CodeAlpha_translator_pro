import { useState, useRef, useEffect } from "react";
import { LANGUAGES, NON_AUTO_LANGUAGES, POPULAR_LANGUAGES, Language } from "../lib/languages";
import { ChevronDown, Search, Star } from "lucide-react";

interface Props {
  value: string;
  onChange: (code: string) => void;
  allowAuto?: boolean;
  label?: string;
}

export function LanguageSelect({ value, onChange, allowAuto = false, label }: Props) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const languages = allowAuto ? LANGUAGES : NON_AUTO_LANGUAGES;
  const selected = languages.find(l => l.code === value) || languages[0];

  const filtered = search
    ? languages.filter(l =>
        l.name.toLowerCase().includes(search.toLowerCase()) ||
        l.nativeName.toLowerCase().includes(search.toLowerCase()) ||
        l.code.toLowerCase().includes(search.toLowerCase())
      )
    : languages;

  const popular = !search ? languages.filter(l => POPULAR_LANGUAGES.includes(l.code)) : [];

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setSearch("");
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => searchRef.current?.focus(), 50);
  }, [open]);

  function select(code: string) {
    onChange(code);
    setOpen(false);
    setSearch("");
  }

  return (
    <div ref={ref} className="relative">
      {label && <div className="text-xs text-muted-foreground mb-1 font-medium">{label}</div>}
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary hover:bg-muted border border-border transition-colors text-sm font-medium min-w-[160px] justify-between"
      >
        <span className="flex items-center gap-2 truncate">
          <span className="text-base leading-none">{selected.flag}</span>
          <span className="truncate">{selected.name}</span>
        </span>
        <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute z-50 mt-1 w-72 bg-card border border-border rounded-xl shadow-xl overflow-hidden">
          <div className="p-2 border-b border-border">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                ref={searchRef}
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search language..."
                className="w-full pl-8 pr-3 py-1.5 text-sm bg-muted rounded-md border-0 outline-none focus:ring-1 focus:ring-ring"
              />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {!search && popular.length > 0 && (
              <>
                <div className="px-3 py-1.5 text-xs text-muted-foreground font-semibold uppercase tracking-wider flex items-center gap-1">
                  <Star className="h-3 w-3" /> Popular
                </div>
                {popular.map(lang => (
                  <LanguageOption key={lang.code} lang={lang} selected={value === lang.code} onSelect={select} />
                ))}
                <div className="my-1 border-t border-border" />
                <div className="px-3 py-1.5 text-xs text-muted-foreground font-semibold uppercase tracking-wider">All Languages</div>
              </>
            )}
            {filtered.map(lang => (
              <LanguageOption key={lang.code} lang={lang} selected={value === lang.code} onSelect={select} />
            ))}
            {filtered.length === 0 && (
              <div className="px-3 py-6 text-center text-sm text-muted-foreground">No languages found</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function LanguageOption({ lang, selected, onSelect }: { lang: Language; selected: boolean; onSelect: (c: string) => void }) {
  return (
    <button
      onClick={() => onSelect(lang.code)}
      className={`w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-muted transition-colors text-left ${selected ? "bg-accent text-accent-foreground font-medium" : ""}`}
    >
      <span className="text-base w-6 text-center leading-none">{lang.flag}</span>
      <span className="flex-1 truncate">{lang.name}</span>
      <span className="text-xs text-muted-foreground shrink-0">{lang.nativeName}</span>
    </button>
  );
}
