import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeftRight, Copy, Volume2, Mic, MicOff, X, Star, Check,
  Loader2, AlertCircle, Clipboard, Type, Hash
} from "lucide-react";
import { LanguageSelect } from "../components/LanguageSelect";
import { translateLongText } from "../lib/translate";
import { addHistory, AppSettings } from "../lib/storage";
import { getLanguage, isRTL } from "../lib/languages";
import {
  isSpeechRecognitionSupported, isSpeechSynthesisSupported,
  startSpeechRecognition, stopSpeechRecognition, speakText, cancelSpeech
} from "../lib/speech";
import { HistoryEntry } from "../lib/storage";

interface Props {
  settings: AppSettings;
  onNewTranslation: (entry: HistoryEntry) => void;
  initialEntry?: HistoryEntry | null;
}

const FONT_SIZES = { sm: "text-sm", md: "text-base", lg: "text-lg" };

export function Translator({ settings, onNewTranslation, initialEntry }: Props) {
  const [sourceText, setSourceText] = useState(initialEntry?.sourceText || "");
  const [targetText, setTargetText] = useState(initialEntry?.translatedText || "");
  const [sourceLang, setSourceLang] = useState(initialEntry?.sourceLang || settings.defaultSourceLang);
  const [targetLang, setTargetLang] = useState(initialEntry?.targetLang || settings.defaultTargetLang);
  const [isTranslating, setIsTranslating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<"source" | "target" | null>(null);
  const [isFavorited, setIsFavorited] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [mode, setMode] = useState<"text" | "voice">("text");
  const [charCount, setCharCount] = useState(0);
  const [wordCount, setWordCount] = useState(0);
  const [progress, setProgress] = useState(0);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const translationIdRef = useRef(0);
  const sourceRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initialEntry) {
      setSourceText(initialEntry.sourceText);
      setTargetText(initialEntry.translatedText);
      setSourceLang(initialEntry.sourceLang);
      setTargetLang(initialEntry.targetLang);
    }
  }, [initialEntry]);

  useEffect(() => {
    setCharCount(sourceText.length);
    setWordCount(sourceText.trim() ? sourceText.trim().split(/\s+/).length : 0);
  }, [sourceText]);

  const doTranslate = useCallback(async (text: string, from: string, to: string) => {
    if (!text.trim()) { setTargetText(""); setError(null); return; }
    const id = ++translationIdRef.current;
    setIsTranslating(true);
    setError(null);
    setProgress(0);
    try {
      const result = await translateLongText(text, from, to, (p) => {
        if (id === translationIdRef.current) setProgress(p);
      });
      if (id !== translationIdRef.current) return;
      setTargetText(result.translatedText);
      setIsFavorited(false);
      if (result.translatedText && text.trim()) {
        const entry = addHistory({ sourceText: text, translatedText: result.translatedText, sourceLang: from, targetLang: to });
        onNewTranslation(entry);
      }
    } catch (e) {
      if (id === translationIdRef.current) setError((e as Error).message || "Translation failed");
    } finally {
      if (id === translationIdRef.current) { setIsTranslating(false); setProgress(0); }
    }
  }, [onNewTranslation]);

  useEffect(() => {
    if (!settings.autoTranslate || !sourceText.trim()) return;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => doTranslate(sourceText, sourceLang, targetLang), settings.autoTranslateDelay);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [sourceText, sourceLang, targetLang, settings.autoTranslate, settings.autoTranslateDelay, doTranslate]);

  function handleSwap() {
    if (sourceLang === "auto") return;
    setSourceText(targetText); setTargetText(sourceText);
    setSourceLang(targetLang); setTargetLang(sourceLang);
  }

  function handleCopy(which: "source" | "target") {
    const text = which === "source" ? sourceText : targetText;
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopied(which);
    setTimeout(() => setCopied(null), 1500);
  }

  function handleSpeak(which: "source" | "target") {
    if (isSpeaking) { cancelSpeech(); setIsSpeaking(false); return; }
    const text = which === "source" ? sourceText : targetText;
    const lang = which === "source" ? sourceLang : targetLang;
    if (!text || lang === "auto") return;
    setIsSpeaking(true);
    speakText(text, lang);
    const interval = setInterval(() => {
      if (!window.speechSynthesis.speaking) { setIsSpeaking(false); clearInterval(interval); }
    }, 200);
  }

  function handlePaste() {
    navigator.clipboard.readText().then(t => setSourceText(t)).catch(() => sourceRef.current?.focus());
  }

  function handleMicToggle() {
    if (isListening) { stopSpeechRecognition(); setIsListening(false); return; }
    setIsListening(true);
    let accumulated = "";
    startSpeechRecognition(
      sourceLang,
      (text, isFinal) => {
        if (isFinal) { accumulated += (accumulated ? " " : "") + text; setSourceText(accumulated); }
        else setSourceText(accumulated + (accumulated ? " " : "") + text);
      },
      () => setIsListening(false),
      (err) => { setError(`Voice error: ${err}`); setIsListening(false); }
    );
  }

  const fs = FONT_SIZES[settings.fontSize];
  const sourceIsRTL = isRTL(sourceLang);
  const targetIsRTL = isRTL(targetLang);

  return (
    <div className="flex flex-col h-full gap-0">
      <div className="flex items-center gap-2 bg-card border border-border rounded-2xl p-1 mb-4 w-fit self-center">
        <button onClick={() => setMode("text")} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-sm font-medium transition-all ${mode === "text" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
          <Type className="h-4 w-4" /> Text
        </button>
        <button onClick={() => { setMode("voice"); if (!isListening) handleMicToggle(); }} className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-sm font-medium transition-all ${mode === "voice" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
          <Mic className="h-4 w-4" /> Voice
        </button>
      </div>

      <div className="flex items-center gap-3 mb-3">
        <div className="flex-1"><LanguageSelect value={sourceLang} onChange={setSourceLang} allowAuto label="From" /></div>
        <button onClick={handleSwap} disabled={sourceLang === "auto"} className="p-2.5 rounded-xl border border-border bg-card hover:bg-muted transition-all disabled:opacity-40 disabled:cursor-not-allowed mt-5" title="Swap languages">
          <ArrowLeftRight className="h-4 w-4" />
        </button>
        <div className="flex-1"><LanguageSelect value={targetLang} onChange={setTargetLang} label="To" /></div>
      </div>

      {progress > 0 && progress < 1 && (
        <div className="w-full h-1 bg-muted rounded-full mb-3 overflow-hidden">
          <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${progress * 100}%` }} />
        </div>
      )}

      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-3 min-h-0">
        <div className="flex flex-col bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
          <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/40">
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground">{charCount} chars</span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="text-xs text-muted-foreground">{wordCount} words</span>
            </div>
            <div className="flex items-center gap-1">
              {isSpeechRecognitionSupported() && (
                <button onClick={handleMicToggle} className={`p-1.5 rounded-lg transition-all ${isListening ? "bg-red-500 text-white" : "hover:bg-muted text-muted-foreground hover:text-foreground"}`} title={isListening ? "Stop" : "Voice input"}>
                  {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </button>
              )}
              <button onClick={handlePaste} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" title="Paste">
                <Clipboard className="h-4 w-4" />
              </button>
              <button onClick={() => handleCopy("source")} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" title="Copy" disabled={!sourceText}>
                {copied === "source" ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </button>
              {sourceText && (
                <button onClick={() => { setSourceText(""); setTargetText(""); setError(null); }} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors" title="Clear">
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
          <textarea
            ref={sourceRef}
            value={sourceText}
            onChange={e => setSourceText(e.target.value)}
            placeholder={isListening ? "Listening..." : "Enter text to translate..."}
            dir={sourceIsRTL ? "rtl" : "ltr"}
            className={`flex-1 resize-none p-4 bg-transparent outline-none ${fs} leading-relaxed placeholder:text-muted-foreground/50 min-h-[200px]`}
          />
          {!settings.autoTranslate && sourceText && (
            <div className="px-3 py-2 border-t border-border">
              <button onClick={() => doTranslate(sourceText, sourceLang, targetLang)} disabled={isTranslating} className="w-full py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
                {isTranslating && <Loader2 className="h-4 w-4 animate-spin" />}
                Translate
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
          <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/40">
            <div className="flex items-center gap-1.5">
              {isTranslating ? (
                <span className="text-xs text-primary flex items-center gap-1"><Loader2 className="h-3 w-3 animate-spin" />Translating...</span>
              ) : targetText ? (
                <span className="text-xs text-muted-foreground">{targetText.length} chars</span>
              ) : (
                <span className="text-xs text-muted-foreground">Translation</span>
              )}
            </div>
            <div className="flex items-center gap-1">
              {isSpeechSynthesisSupported() && (
                <button onClick={() => handleSpeak("target")} disabled={!targetText || targetLang === "auto"} className={`p-1.5 rounded-lg transition-colors ${isSpeaking ? "text-primary bg-accent" : "hover:bg-muted text-muted-foreground hover:text-foreground"} disabled:opacity-30`} title="Listen">
                  <Volume2 className="h-4 w-4" />
                </button>
              )}
              <button onClick={() => setIsFavorited(!isFavorited)} disabled={!targetText} className="p-1.5 rounded-lg hover:bg-muted transition-colors disabled:opacity-30" title="Favorite">
                <Star className={`h-4 w-4 ${isFavorited ? "fill-yellow-500 text-yellow-500" : "text-muted-foreground"}`} />
              </button>
              <button onClick={() => handleCopy("target")} disabled={!targetText} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors disabled:opacity-30" title="Copy">
                {copied === "target" ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div className={`flex-1 p-4 overflow-y-auto min-h-[200px] ${fs} leading-relaxed`} dir={targetIsRTL ? "rtl" : "ltr"}>
            {error ? (
              <div className="flex items-start gap-2 text-destructive">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <p className="text-sm">{error}</p>
              </div>
            ) : isTranslating && !targetText ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <span className="text-sm">Translating...</span>
              </div>
            ) : (
              <p className={`whitespace-pre-wrap ${!targetText ? "text-muted-foreground/40" : ""}`}>
                {targetText || "Translation will appear here..."}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        {["en", "es", "fr", "de", "ja", "ko", "zh-CN", "ar", "hi", "pt"].map(code => {
          const lang = getLanguage(code);
          if (!lang) return null;
          const isActive = targetLang === code;
          return (
            <button key={code} onClick={() => setTargetLang(code)} className={`text-xs px-2.5 py-1 rounded-full border transition-all ${isActive ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary/40 hover:bg-accent"}`}>
              {lang.flag} {lang.name}
            </button>
          );
        })}
      </div>
    </div>
  );
}
