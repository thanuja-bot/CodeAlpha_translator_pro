# College FAQ Bot

A chatbot that answers frequently asked questions about college using NLP-based cosine similarity matching.

## Features

- 25+ pre-loaded college FAQs (admissions, financial aid, housing, academics, and more)
- Text preprocessing: lowercasing, punctuation removal, stopword filtering
- TF (Term Frequency) vector representation for each question
- Cosine similarity matching to find the most relevant FAQ
- Clean chat UI with conversation history

## Tech Stack

- **Backend**: Python 3.10+ / Flask
- **NLP**: Pure stdlib — TF vectors + cosine similarity (no heavy ML dependencies)
- **Frontend**: HTML5, CSS3, vanilla JavaScript

## Setup & Run

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the app

```bash
python app.py
```

The app will be available at `http://localhost:5000`.

## Project Structure

```
college-faq-bot/
├── app.py              # Flask server + NLP matching logic
├── faqs.json           # FAQ dataset (questions & answers)
├── requirements.txt    # Python dependencies
├── templates/
│   └── index.html      # Chat UI
├── static/
│   ├── css/
│   │   └── style.css   # Styles
│   └── js/
│       └── chat.js     # Frontend chat logic
└── README.md
```

## How It Works

1. On startup, the app loads all FAQs from `faqs.json` and pre-computes a TF (Term Frequency) vector for each question.
2. When a user sends a message, the server:
   - Tokenizes and cleans the input (removes stopwords, punctuation)
   - Computes the TF vector for the query
   - Calculates cosine similarity between the query vector and every FAQ vector
   - Returns the FAQ answer with the highest similarity score (if above a threshold)
3. If no FAQ scores above the threshold, a fallback message is shown.

## Adding More FAQs

Edit `faqs.json` and add entries in the format:

```json
{
  "question": "Your question here?",
  "answer": "Your answer here."
}
```

Restart the server for changes to take effect.
