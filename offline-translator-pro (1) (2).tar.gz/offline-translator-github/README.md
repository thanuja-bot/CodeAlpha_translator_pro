# Offline Translator Pro

A fully-featured, open-source web translator supporting **100+ languages** with voice input, text-to-speech, translation history, and offline support.

## Features

- **100+ Languages** — Auto-detect, swap languages, quick language pills
- **Voice Input** — Speak to translate using Web Speech API (Chrome/Edge)
- **Text-to-Speech** — Listen to translations in native accent
- **Auto Translate** — Translates as you type with configurable delay
- **Translation History** — Last 200 translations saved locally
- **Favorites** — Star and bookmark important translations
- **Dark/Light/System Theme** — Follows your OS preference
- **Offline Capable** — Service worker caches the app shell
- **RTL Support** — Arabic, Hebrew, Farsi, Urdu and more
- **No account required** — Everything stored in your browser
- **Free** — Uses MyMemory API (free tier) with LibreTranslate fallback

## Screenshots

The app has three tabs:
- **Translate** — Main translation panel with source/target text areas
- **History** — Searchable, filterable translation history
- **Settings** — Theme, font size, auto-translate delay, default languages

## Getting Started

### Requirements
- Node.js 18+
- npm or pnpm

### Install & Run

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/offline-translator-pro.git
cd offline-translator-pro

# Install dependencies
npm install

# Start dev server
npm run dev
```

Open http://localhost:5173 in your browser.

### Build for Production

```bash
npm run build
```

The output is in `dist/`. You can deploy it to:
- **GitHub Pages** — `gh-pages -d dist`
- **Netlify** — Drag and drop `dist/` to netlify.com
- **Vercel** — `vercel --prod`
- **Any static host** — Upload `dist/` contents

## Deploy to GitHub Pages

```bash
npm install -D gh-pages
npx gh-pages -d dist
```

Or use the GitHub Actions workflow in `.github/workflows/deploy.yml`.

## Translation Providers

The app uses two free translation APIs:

1. **MyMemory** (primary) — https://mymemory.translated.net
   - Free: 500 words/day per IP without API key
   - With email registration: 10,000 words/day

2. **LibreTranslate** (fallback) — https://libretranslate.com
   - Open-source, can be self-hosted
   - Public instance used as fallback

### Self-hosting LibreTranslate

For true offline translation (no internet), run LibreTranslate locally:

```bash
pip install libretranslate
libretranslate --port 5000
```

Then update `src/lib/translate.ts` to point to `http://localhost:5000`.

## Tech Stack

- **React 19** + TypeScript
- **Vite 6** — Build tool
- **Tailwind CSS v4** — Styling
- **Lucide React** — Icons
- **Web Speech API** — Voice input & TTS (built into browsers)
- **localStorage** — History & settings persistence
- **Service Worker** — Offline app shell caching

## Project Structure

```
src/
├── App.tsx              # Main app with tab navigation
├── main.tsx             # Entry point + SW registration
├── index.css            # Global styles & CSS variables
├── lib/
│   ├── languages.ts     # 100+ language definitions
│   ├── translate.ts     # Translation API logic
│   ├── storage.ts       # localStorage helpers
│   └── speech.ts        # Web Speech API wrappers
├── components/
│   └── LanguageSelect.tsx  # Searchable language dropdown
└── pages/
    ├── Translator.tsx   # Main translation UI
    ├── History.tsx      # Translation history
    └── Settings.tsx     # App settings
```

## Browser Compatibility

| Feature | Chrome | Firefox | Safari | Edge |
|---|---|---|---|---|
| Translation | ✅ | ✅ | ✅ | ✅ |
| Voice Input | ✅ | ❌ | ✅ | ✅ |
| Text-to-Speech | ✅ | ✅ | ✅ | ✅ |
| Offline (SW) | ✅ | ✅ | ✅ | ✅ |

## License

MIT — Free to use, modify, and distribute.
