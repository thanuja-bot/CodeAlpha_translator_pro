export function isSpeechRecognitionSupported(): boolean {
  return typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window);
}

export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

type SpeechCallback = (text: string, isFinal: boolean) => void;
type SpeechEndCallback = () => void;
type SpeechErrorCallback = (error: string) => void;

let recognition: SpeechRecognition | null = null;

export function startSpeechRecognition(
  lang: string,
  onResult: SpeechCallback,
  onEnd: SpeechEndCallback,
  onError: SpeechErrorCallback
): () => void {
  if (!isSpeechRecognitionSupported()) {
    onError("Speech recognition is not supported in this browser.");
    return () => {};
  }

  const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  recognition = new SpeechRec();
  recognition!.lang = lang === "auto" ? "en-US" : lang;
  recognition!.continuous = true;
  recognition!.interimResults = true;
  recognition!.maxAlternatives = 1;

  recognition!.onresult = (event: SpeechRecognitionEvent) => {
    let interim = "";
    let final = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const t = event.results[i][0].transcript;
      if (event.results[i].isFinal) final += t;
      else interim += t;
    }
    if (final) onResult(final, true);
    else if (interim) onResult(interim, false);
  };

  recognition!.onerror = (event: SpeechRecognitionErrorEvent) => {
    if (event.error !== "aborted") onError(event.error);
    onEnd();
  };

  recognition!.onend = onEnd;

  recognition!.start();

  return () => {
    recognition?.stop();
    recognition = null;
  };
}

export function stopSpeechRecognition() {
  recognition?.stop();
  recognition = null;
}

export function speakText(text: string, lang: string): void {
  if (!isSpeechSynthesisSupported()) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = lang;
  utterance.rate = 0.9;
  utterance.pitch = 1;
  const voices = window.speechSynthesis.getVoices();
  const voice = voices.find(v => v.lang.startsWith(lang)) ||
    voices.find(v => v.lang.startsWith(lang.split("-")[0]));
  if (voice) utterance.voice = voice;
  window.speechSynthesis.speak(utterance);
}

export function cancelSpeech(): void {
  window.speechSynthesis?.cancel();
}
