export interface TranslationResult {
  translatedText: string;
  detectedLanguage?: string;
  confidence?: number;
  provider: string;
}

export interface TranslationError {
  message: string;
  code?: string;
}

async function translateMyMemory(
  text: string,
  from: string,
  to: string
): Promise<TranslationResult> {
  const fromCode = from === "auto" ? "autodetect" : from;
  const langpair = fromCode === "autodetect" ? `${to}` : `${fromCode}|${to}`;
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${from === "auto" ? `en|${to}` : `${from}|${to}`}`;

  const response = await fetch(url, {
    signal: AbortSignal.timeout(10000),
  });

  if (!response.ok) {
    throw new Error(`MyMemory API error: ${response.status}`);
  }

  const data = await response.json();

  if (data.responseStatus !== 200) {
    throw new Error(data.responseDetails || "Translation failed");
  }

  return {
    translatedText: data.responseData.translatedText,
    detectedLanguage: data.detectedLanguage?.language,
    confidence: data.responseData.match,
    provider: "MyMemory",
  };
}

async function translateLibreTranslate(
  text: string,
  from: string,
  to: string
): Promise<TranslationResult> {
  const response = await fetch("https://libretranslate.com/translate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      q: text,
      source: from === "auto" ? "auto" : from,
      target: to,
      format: "text",
    }),
    signal: AbortSignal.timeout(10000),
  });

  if (!response.ok) {
    throw new Error(`LibreTranslate error: ${response.status}`);
  }

  const data = await response.json();

  return {
    translatedText: data.translatedText,
    detectedLanguage: data.detectedLanguage?.language,
    provider: "LibreTranslate",
  };
}

export async function translate(
  text: string,
  from: string,
  to: string
): Promise<TranslationResult> {
  if (!text.trim()) {
    return { translatedText: "", provider: "none" };
  }

  if (from === to && from !== "auto") {
    return { translatedText: text, provider: "passthrough" };
  }

  const errors: string[] = [];

  try {
    return await translateMyMemory(text, from, to);
  } catch (e) {
    errors.push(`MyMemory: ${(e as Error).message}`);
  }

  try {
    return await translateLibreTranslate(text, from, to);
  } catch (e) {
    errors.push(`LibreTranslate: ${(e as Error).message}`);
  }

  throw new Error(
    `All translation providers failed. ${errors.join("; ")}`
  );
}

export function splitIntoChunks(text: string, maxLength = 400): string[] {
  if (text.length <= maxLength) return [text];

  const chunks: string[] = [];
  const sentences = text.match(/[^.!?\n]+[.!?\n]*/g) || [text];
  let current = "";

  for (const sentence of sentences) {
    if ((current + sentence).length > maxLength && current) {
      chunks.push(current.trim());
      current = sentence;
    } else {
      current += sentence;
    }
  }

  if (current.trim()) chunks.push(current.trim());
  return chunks;
}

export async function translateLongText(
  text: string,
  from: string,
  to: string,
  onProgress?: (progress: number) => void
): Promise<TranslationResult> {
  const chunks = splitIntoChunks(text);

  if (chunks.length === 1) {
    return translate(text, from, to);
  }

  const results: string[] = [];
  let lastProvider = "MyMemory";

  for (let i = 0; i < chunks.length; i++) {
    const result = await translate(chunks[i], from, to);
    results.push(result.translatedText);
    lastProvider = result.provider;
    onProgress?.((i + 1) / chunks.length);
    if (i < chunks.length - 1) {
      await new Promise(r => setTimeout(r, 200));
    }
  }

  return {
    translatedText: results.join(" "),
    provider: lastProvider,
  };
}
