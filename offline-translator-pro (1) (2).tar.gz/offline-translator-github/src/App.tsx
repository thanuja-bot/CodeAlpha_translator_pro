import { useState, useEffect } from "react";
import { Languages, History as HistoryIcon, Settings as SettingsIcon, Wifi, WifiOff } from "lucide-react";
import { Translator } from "./pages/Translator";
import { History } from "./pages/History";
import { Settings } from "./pages/Settings";
import { getHistory, getSettings, AppSettings } from "./lib/storage";
import { HistoryEntry } from "./lib/storage";

type Tab = "translator" | "history" | "settings";

export default function App() {
  const [tab, setTab] = useState<Tab>("translator");
  const [history, setHistory] = useState<HistoryEntry[]>(() => getHistory());
  const [settings, setSettings] = useState<AppSettings>(() => getSettings());
  const [loadEntry, setLoadEntry] = useState<HistoryEntry | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const theme = settings.theme;
    if (theme === "dark") {
      root.classList.add("dark");
    } else if (theme === "light") {
      root.classList.remove("dark");
    } else {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      if (prefersDark) root.classList.add("dark");
      else root.classList.remove("dark");
    }
  }, [settings.theme]);

  function handleLoadTranslation(entry: HistoryEntry) {
    setLoadEntry(entry);
    setTab("translator");
  }

  function handleNewTranslation(entry: HistoryEntry) {
    setHistory(prev => {
      const filtered = prev.filter(h =>
        !(h.sourceText === entry.sourceText &&
          h.sourceLang === entry.sourceLang &&
          h.targetLang === entry.targetLang)
      );
      return [entry, ...filtered].slice(0, 200);
    });
  }

  const tabs: { id: Tab; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: "translator", label: "Translate", icon: <Languages className="h-5 w-5" /> },
    { id: "history", label: "History", icon: <HistoryIcon className="h-5 w-5" />, badge: history.length || undefined },
    { id: "settings", label: "Settings", icon: <SettingsIcon className="h-5 w-5" /> },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-30 bg-card/80 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-sm">
              <Languages className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-none">Offline Translator</h1>
              <p className="text-xs text-muted-foreground leading-none mt-0.5">Pro Edition</p>
            </div>
          </div>
          <div className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full ${isOnline ? "bg-green-50 text-green-700 dark:bg-green-900/30 dark:text-green-400" : "bg-red-50 text-red-700 dark:bg-red-900/30 dark:text-red-400"}`}>
            {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
            {isOnline ? "Online" : "Offline"}
          </div>
        </div>
      </header>

      <nav className="bg-card border-b border-border sticky top-[61px] z-20">
        <div className="max-w-5xl mx-auto px-4 flex gap-1">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-all ${
                tab === t.id
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
              }`}
            >
              {t.icon}
              {t.label}
              {t.badge !== undefined && t.badge > 0 && (
                <span className="bg-primary/10 text-primary text-xs px-1.5 py-0.5 rounded-full font-semibold min-w-[1.2rem] text-center">
                  {t.badge > 99 ? "99+" : t.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </nav>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">
        {tab === "translator" && (
          <Translator
            settings={settings}
            onNewTranslation={handleNewTranslation}
            initialEntry={loadEntry}
            key={loadEntry?.id}
          />
        )}
        {tab === "history" && (
          <History
            history={history}
            onHistoryChange={setHistory}
            onLoadTranslation={handleLoadTranslation}
          />
        )}
        {tab === "settings" && (
          <Settings settings={settings} onSettingsChange={setSettings} />
        )}
      </main>

      <footer className="border-t border-border py-3 px-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between text-xs text-muted-foreground">
          <span>Offline Translator Pro — Open Source</span>
          <span>100+ languages · Voice input · Works offline</span>
        </div>
      </footer>
    </div>
  );
}
