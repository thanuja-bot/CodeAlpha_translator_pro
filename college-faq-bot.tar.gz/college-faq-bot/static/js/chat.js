"use strict";

// ─── State ─────────────────────────────────────────────────────────────────
const sessions = [];   // [{id, title, messages:[]}]
let activeId = null;

// ─── DOM refs ───────────────────────────────────────────────────────────────
const messagesEl   = document.getElementById("messages");
const userInputEl  = document.getElementById("userInput");
const sendBtnEl    = document.getElementById("sendBtn");
const chatHistoryEl= document.getElementById("chatHistory");
const newChatBtnEl = document.getElementById("newChatBtn");
const chatTitleEl  = document.getElementById("chatTitle");
const faqCountEl   = document.getElementById("faqCount");

// ─── Bootstrap ──────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  fetchFaqCount();
  newConversation();

  sendBtnEl.addEventListener("click", handleSend);
  newChatBtnEl.addEventListener("click", newConversation);

  userInputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });

  // Auto-resize textarea
  userInputEl.addEventListener("input", () => {
    userInputEl.style.height = "auto";
    userInputEl.style.height = userInputEl.scrollHeight + "px";
  });

  // Suggestion chips
  document.querySelectorAll(".suggestion-chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      userInputEl.value = btn.dataset.q;
      handleSend();
    });
  });
});

async function fetchFaqCount() {
  try {
    const res = await fetch("/api/faqs");
    if (!res.ok) return;
    const faqs = await res.json();
    faqCountEl.textContent = `${faqs.length} FAQs loaded`;
  } catch {
    faqCountEl.textContent = "FAQs unavailable";
  }
}

// ─── Session management ─────────────────────────────────────────────────────
function newConversation() {
  const id = Date.now().toString();
  const session = { id, title: "New Conversation", messages: [] };
  sessions.unshift(session);
  activeId = id;
  renderSidebar();
  renderWelcome();
  chatTitleEl.textContent = "New Conversation";
  userInputEl.value = "";
  userInputEl.style.height = "auto";
  userInputEl.focus();
}

function switchSession(id) {
  activeId = id;
  renderSidebar();
  const session = sessions.find((s) => s.id === id);
  chatTitleEl.textContent = session.title;
  renderMessages(session.messages);
}

function activeSession() {
  return sessions.find((s) => s.id === activeId);
}

// ─── Render helpers ─────────────────────────────────────────────────────────
function renderSidebar() {
  chatHistoryEl.innerHTML = "";
  sessions.forEach((s) => {
    const el = document.createElement("div");
    el.className = "history-item" + (s.id === activeId ? " active" : "");
    el.textContent = s.title;
    el.addEventListener("click", () => switchSession(s.id));
    chatHistoryEl.appendChild(el);
  });
}

function renderWelcome() {
  messagesEl.innerHTML = `
    <div class="welcome">
      <div class="welcome-icon">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
          <path d="M6 12v5c3 3 9 3 12 0v-5"/>
        </svg>
      </div>
      <h2>Welcome to College FAQ Bot</h2>
      <p>Ask me anything about admissions, tuition, housing, financial aid, academics, and more.</p>
      <div class="suggestions">
        <button class="suggestion-chip" data-q="What are the admission requirements?">Admission requirements</button>
        <button class="suggestion-chip" data-q="How do I apply for financial aid?">Financial aid</button>
        <button class="suggestion-chip" data-q="What scholarships are available?">Scholarships</button>
        <button class="suggestion-chip" data-q="What is the tuition cost?">Tuition &amp; fees</button>
        <button class="suggestion-chip" data-q="Is on-campus housing available?">Housing</button>
        <button class="suggestion-chip" data-q="What majors does the college offer?">Programs &amp; majors</button>
      </div>
    </div>
  `;
  // Re-attach chip listeners
  messagesEl.querySelectorAll(".suggestion-chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      userInputEl.value = btn.dataset.q;
      handleSend();
    });
  });
}

function renderMessages(messages) {
  if (messages.length === 0) { renderWelcome(); return; }
  messagesEl.innerHTML = "";
  messages.forEach((m) => appendBubble(m.role, m.text, m.matched));
}

function appendBubble(role, text, matched) {
  const row = document.createElement("div");
  row.className = `message-row ${role}`;

  const avatarLabel = role === "bot" ? "AI" : "You";
  const avatarClass = role === "bot" ? "bot-avatar" : "user-avatar";

  const matchedHtml = matched
    ? `<div class="matched-label">Matched: "${matched}"</div>`
    : "";

  row.innerHTML = `
    <div class="avatar ${avatarClass}">${avatarLabel}</div>
    <div>
      <div class="bubble">${escapeHtml(text)}</div>
      ${matchedHtml}
    </div>
  `;

  messagesEl.appendChild(row);
  scrollToBottom();
}

function showTyping() {
  const row = document.createElement("div");
  row.className = "message-row bot typing-indicator";
  row.id = "typing";
  row.innerHTML = `
    <div class="avatar bot-avatar">AI</div>
    <div class="bubble">
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
    </div>
  `;
  messagesEl.appendChild(row);
  scrollToBottom();
}

function hideTyping() {
  const el = document.getElementById("typing");
  if (el) el.remove();
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ─── Send & API call ────────────────────────────────────────────────────────
async function handleSend() {
  const text = userInputEl.value.trim();
  if (!text) return;

  // Clear input
  userInputEl.value = "";
  userInputEl.style.height = "auto";
  sendBtnEl.disabled = true;

  // Ensure welcome screen is gone
  const welcome = messagesEl.querySelector(".welcome");
  if (welcome) messagesEl.innerHTML = "";

  // Add user bubble
  appendBubble("user", text, null);
  const session = activeSession();
  session.messages.push({ role: "user", text, matched: null });

  // Update sidebar title on first message
  if (session.messages.filter(m => m.role === "user").length === 1) {
    session.title = text.length > 36 ? text.slice(0, 36) + "…" : text;
    chatTitleEl.textContent = session.title;
    renderSidebar();
  }

  // Show typing
  showTyping();

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    });

    hideTyping();

    if (!res.ok) throw new Error("Server error");

    const data = await res.json();
    const botText = data.response || "I'm sorry, I couldn't find an answer.";
    const matched = data.matched_question || null;

    appendBubble("bot", botText, matched);
    session.messages.push({ role: "bot", text: botText, matched });
  } catch (err) {
    hideTyping();
    const errMsg = "Sorry, I encountered an error. Please try again.";
    appendBubble("bot", errMsg, null);
    session.messages.push({ role: "bot", text: errMsg, matched: null });
  } finally {
    sendBtnEl.disabled = false;
    userInputEl.focus();
  }
}
