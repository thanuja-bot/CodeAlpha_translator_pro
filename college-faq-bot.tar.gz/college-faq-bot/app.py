import json
import os
import re
import math
import string
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# ---------------------------------------------------------------------------
# Load FAQ data
# ---------------------------------------------------------------------------
FAQ_PATH = os.path.join(os.path.dirname(__file__), "faqs.json")

with open(FAQ_PATH, "r", encoding="utf-8") as f:
    FAQS = json.load(f)

# ---------------------------------------------------------------------------
# NLP helpers (no heavy dependencies — pure stdlib TF-IDF + cosine)
# ---------------------------------------------------------------------------

STOPWORDS = {
    "a", "an", "the", "is", "it", "in", "on", "at", "to", "for", "of",
    "and", "or", "but", "if", "be", "are", "was", "were", "this", "that",
    "what", "when", "where", "who", "which", "how", "do", "does", "did",
    "can", "will", "my", "i", "me", "we", "our", "you", "your", "have",
    "has", "had", "not", "with", "from", "by", "about", "as", "its",
    "than", "then", "so", "no", "there", "their", "they", "he", "she",
    "his", "her", "up", "out", "get", "got", "am", "would", "should",
    "could", "us", "any", "all", "also", "more", "some", "just", "into",
}


def tokenize(text: str) -> list[str]:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = text.split()
    tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 1]
    return tokens


def build_tf(tokens: list[str]) -> dict[str, float]:
    tf: dict[str, float] = {}
    total = len(tokens) or 1
    for t in tokens:
        tf[t] = tf.get(t, 0) + 1
    for t in tf:
        tf[t] /= total
    return tf


def cosine_similarity(vec_a: dict[str, float], vec_b: dict[str, float]) -> float:
    keys = set(vec_a) & set(vec_b)
    if not keys:
        return 0.0
    dot = sum(vec_a[k] * vec_b[k] for k in keys)
    mag_a = math.sqrt(sum(v * v for v in vec_a.values()))
    mag_b = math.sqrt(sum(v * v for v in vec_b.values()))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


# Pre-compute TF vectors for every FAQ question
_faq_vectors = []
for faq in FAQS:
    tokens = tokenize(faq["question"])
    _faq_vectors.append(build_tf(tokens))


def find_best_match(user_query: str) -> dict:
    tokens = tokenize(user_query)
    if not tokens:
        return {"answer": "Please ask a question about the college!", "score": 0.0, "matched_question": ""}

    query_vec = build_tf(tokens)
    best_score = 0.0
    best_idx = -1

    for idx, faq_vec in enumerate(_faq_vectors):
        score = cosine_similarity(query_vec, faq_vec)
        if score > best_score:
            best_score = score
            best_idx = idx

    THRESHOLD = 0.05
    if best_idx == -1 or best_score < THRESHOLD:
        return {
            "answer": "I'm sorry, I couldn't find a matching answer. Please contact the college admissions office for more information.",
            "score": 0.0,
            "matched_question": "",
        }

    matched = FAQS[best_idx]
    return {
        "answer": matched["answer"],
        "score": round(best_score, 4),
        "matched_question": matched["question"],
    }


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    user_message = str(data.get("message", "")).strip()

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    result = find_best_match(user_message)
    return jsonify({
        "response": result["answer"],
        "matched_question": result["matched_question"],
        "confidence": result["score"],
    })


@app.route("/api/faqs", methods=["GET"])
def list_faqs():
    return jsonify(FAQS)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
