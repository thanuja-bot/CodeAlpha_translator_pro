export interface HistoryEntry {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  timestamp: number;
  isFavorite?: boolean;
}

export interface AppSettings {
  theme: "light" | "dark" | "system";
  autoTranslate: boolean;
  autoTranslateDelay: number;
  fontSize: "sm" | "md" | "lg";
  defaultSourceLang: string;
  defaultTargetLang: string;
  soundEnabled: boolean;
}

const HISTORY_KEY = "translator_history";
const SETTINGS_KEY = "translator_settings";
const MAX_HISTORY = 200;

export const DEFAULT_SETTINGS: AppSettings = {
  theme: "system",
  autoTranslate: true,
  autoTranslateDelay: 800,
  fontSize: "md",
  defaultSourceLang: "auto",
  defaultTargetLang: "en",
  soundEnabled: false,
};

export function getHistory(): HistoryEntry[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addHistory(entry: Omit<HistoryEntry, "id" | "timestamp">): HistoryEntry {
  const history = getHistory();
  const newEntry: HistoryEntry = {
    ...entry,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
  };

  const duplicate = history.find(
    h => h.sourceText === entry.sourceText &&
      h.sourceLang === entry.sourceLang &&
      h.targetLang === entry.targetLang
  );

  if (duplicate) {
    const idx = history.indexOf(duplicate);
    history.splice(idx, 1);
  }

  history.unshift(newEntry);
  const trimmed = history.slice(0, MAX_HISTORY);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(trimmed));
  return newEntry;
}

export function toggleFavorite(id: string): HistoryEntry[] {
  const history = getHistory();
  const entry = history.find(h => h.id === id);
  if (entry) entry.isFavorite = !entry.isFavorite;
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  return history;
}

export function deleteHistory(id: string): HistoryEntry[] {
  const history = getHistory().filter(h => h.id !== id);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  return history;
}

export function clearHistory(): void {
  const favorites = getHistory().filter(h => h.isFavorite);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(favorites));
}

export function getFavorites(): HistoryEntry[] {
  return getHistory().filter(h => h.isFavorite);
}

export function getSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Partial<AppSettings>): AppSettings {
  const current = getSettings();
  const updated = { ...current, ...settings };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
  return updated;
}
