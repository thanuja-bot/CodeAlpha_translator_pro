import { useState } from "react";
import { HistoryEntry, deleteHistory, toggleFavorite, clearHistory, getHistory } from "../lib/storage";
import { getLanguage } from "../lib/languages";
import { Trash2, Star, ArrowRight, Search, RotateCcw, X } from "lucide-react";

interface Props {
  history: HistoryEntry[];
  onHistoryChange: (h: HistoryEntry[]) => void;
  onLoadTranslation: (entry: HistoryEntry) => void;
}

export function History({ history, onHistoryChange, onLoadTranslation }: Props) {
  const [search, setSearch] = useState("");
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  const filtered = history.filter(h => {
    if (showFavoritesOnly && !h.isFavorite) return false;
    if (!search) return true;
    return h.sourceText.toLowerCase().includes(search.toLowerCase()) ||
      h.translatedText.toLowerCase().includes(search.toLowerCase());
  });

  function handleDelete(id: string) { onHistoryChange(deleteHistory(id)); }
  function handleToggleFavorite(id: string) { onHistoryChange(toggleFavorite(id)); }
  function handleClearAll() {
    if (confirm("Clear all non-favorite history?")) { clearHistory(); onHistoryChange(getHistory()); }
  }

  function formatTime(ts: number) {
    const date = new Date(ts);
    const diffMs = Date.now() - ts;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Translation History</h2>
        {history.length > 0 && (
          <button onClick={handleClearAll} className="text-xs text-destructive hover:text-destructive/80 flex items-center gap-1 transition-colors">
            <Trash2 className="h-3.5 w-3.5" /> Clear All
          </button>
        )}
      </div>

      <div className="flex gap-2 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search history..." className="w-full pl-9 pr-3 py-2 text-sm bg-muted border border-border rounded-lg outline-none focus:ring-2 focus:ring-ring" />
          {search && <button onClick={() => setSearch("")} className="absolute right-2 top-1/2 -translate-y-1/2"><X className="h-4 w-4 text-muted-foreground" /></button>}
        </div>
        <button onClick={() => setShowFavoritesOnly(!showFavoritesOnly)} className={`px-3 py-2 rounded-lg text-sm border transition-colors flex items-center gap-1.5 ${showFavoritesOnly ? "bg-yellow-50 border-yellow-300 text-yellow-700 dark:bg-yellow-900/30 dark:border-yellow-600 dark:text-yellow-400" : "border-border bg-muted hover:bg-accent"}`}>
          <Star className={`h-4 w-4 ${showFavoritesOnly ? "fill-yellow-500 text-yellow-500" : ""}`} /> Favorites
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-3">
          <RotateCcw className="h-10 w-10 opacity-20" />
          <p className="text-sm">{history.length === 0 ? "No translations yet" : "No results found"}</p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filtered.map(entry => {
            const srcLang = getLanguage(entry.sourceLang);
            const tgtLang = getLanguage(entry.targetLang);
            return (
              <div key={entry.id} className="bg-card border border-border rounded-xl p-3 group hover:border-primary/40 transition-all">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span>{srcLang?.flag} {srcLang?.name}</span>
                    <ArrowRight className="h-3 w-3" />
                    <span>{tgtLang?.flag} {tgtLang?.name}</span>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleToggleFavorite(entry.id)} className="p-1 rounded hover:bg-muted transition-colors">
                      <Star className={`h-3.5 w-3.5 ${entry.isFavorite ? "fill-yellow-500 text-yellow-500" : "text-muted-foreground"}`} />
                    </button>
                    <button onClick={() => onLoadTranslation(entry)} className="p-1 rounded hover:bg-muted transition-colors">
                      <RotateCcw className="h-3.5 w-3.5 text-muted-foreground" />
                    </button>
                    <button onClick={() => handleDelete(entry.id)} className="p-1 rounded hover:bg-muted transition-colors">
                      <Trash2 className="h-3.5 w-3.5 text-muted-foreground hover:text-destructive" />
                    </button>
                  </div>
                </div>
                <button onClick={() => onLoadTranslation(entry)} className="text-left w-full">
                  <p className="text-sm font-medium line-clamp-2 mb-1">{entry.sourceText}</p>
                  <p className="text-sm text-muted-foreground line-clamp-2">{entry.translatedText}</p>
                </button>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{formatTime(entry.timestamp)}</span>
                  {entry.isFavorite && <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
