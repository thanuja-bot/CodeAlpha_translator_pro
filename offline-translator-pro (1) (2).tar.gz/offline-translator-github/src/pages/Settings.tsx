import { AppSettings, saveSettings } from "../lib/storage";
import { NON_AUTO_LANGUAGES } from "../lib/languages";
import { Settings as SettingsIcon, Moon, Sun, Monitor } from "lucide-react";

interface Props {
  settings: AppSettings;
  onSettingsChange: (s: AppSettings) => void;
}

export function Settings({ settings, onSettingsChange }: Props) {
  function update(partial: Partial<AppSettings>) {
    const updated = saveSettings(partial);
    onSettingsChange(updated);
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-2">
        <SettingsIcon className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold">Settings</h2>
      </div>

      <section className="space-y-3">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Appearance</h3>
        <div className="bg-card border border-border rounded-xl p-4 space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Theme</label>
            <div className="flex gap-2">
              {(["light", "dark", "system"] as const).map(theme => (
                <button key={theme} onClick={() => update({ theme })} className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border text-sm transition-all ${settings.theme === theme ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"}`}>
                  {theme === "light" && <Sun className="h-4 w-4" />}
                  {theme === "dark" && <Moon className="h-4 w-4" />}
                  {theme === "system" && <Monitor className="h-4 w-4" />}
                  <span className="capitalize">{theme}</span>
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm font-medium mb-2 block">Font Size</label>
            <div className="flex gap-2">
              {(["sm", "md", "lg"] as const).map(size => (
                <button key={size} onClick={() => update({ fontSize: size })} className={`flex-1 py-2 rounded-lg border text-sm transition-all ${settings.fontSize === size ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"}`}>
                  {size === "sm" ? "Small" : size === "md" ? "Medium" : "Large"}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-3">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Translation</h3>
        <div className="bg-card border border-border rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Auto Translate</div>
              <div className="text-xs text-muted-foreground">Translate as you type</div>
            </div>
            <button onClick={() => update({ autoTranslate: !settings.autoTranslate })} className={`relative w-11 h-6 rounded-full transition-colors ${settings.autoTranslate ? "bg-primary" : "bg-muted border border-border"}`}>
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${settings.autoTranslate ? "translate-x-5" : ""}`} />
            </button>
          </div>
          {settings.autoTranslate && (
            <div>
              <label className="text-sm font-medium mb-2 block">Auto Translate Delay: {settings.autoTranslateDelay}ms</label>
              <input type="range" min={300} max={2000} step={100} value={settings.autoTranslateDelay} onChange={e => update({ autoTranslateDelay: Number(e.target.value) })} className="w-full accent-primary" />
              <div className="flex justify-between text-xs text-muted-foreground mt-1"><span>300ms (fast)</span><span>2000ms (slow)</span></div>
            </div>
          )}
          <div>
            <label className="text-sm font-medium mb-2 block">Default Source Language</label>
            <select value={settings.defaultSourceLang} onChange={e => update({ defaultSourceLang: e.target.value })} className="w-full px-3 py-2 text-sm bg-muted border border-border rounded-lg outline-none focus:ring-2 focus:ring-ring">
              <option value="auto">Auto Detect</option>
              {NON_AUTO_LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.flag} {l.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-medium mb-2 block">Default Target Language</label>
            <select value={settings.defaultTargetLang} onChange={e => update({ defaultTargetLang: e.target.value })} className="w-full px-3 py-2 text-sm bg-muted border border-border rounded-lg outline-none focus:ring-2 focus:ring-ring">
              {NON_AUTO_LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.flag} {l.name}</option>)}
            </select>
          </div>
        </div>
      </section>

      <section className="space-y-3">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">About</h3>
        <div className="bg-card border border-border rounded-xl p-4 space-y-2 text-sm text-muted-foreground">
          <p><span className="font-medium text-foreground">Offline Translator Pro</span> v2.0</p>
          <p>Supports 100+ languages with voice input and text-to-speech.</p>
          <p>Uses <a href="https://mymemory.translated.net" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MyMemory</a> and <a href="https://libretranslate.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">LibreTranslate</a> for translations.</p>
          <p className="text-xs mt-3">No account required. Translation history saved locally in your browser.</p>
        </div>
      </section>
    </div>
  );
}
